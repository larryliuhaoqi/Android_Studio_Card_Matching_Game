package com.railgunexpress.cardmatchinproject;

public class AllConstants {
    public static final int default_current_player_level = 0;
    public static final double default_current_player_level_progress = 0;
    public static final int default_current_player_coh = 500;
    public static final int time_for_bonus = 90000; //300000; //16099000;
    public static final int default_width = 1600;
    public static final int default_height = 2560;
    public static int ScreenHeight, ScreenWidth;
    public static final int animation_time = 1000;


}
