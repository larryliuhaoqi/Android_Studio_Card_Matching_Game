package com.railgunexpress.cardmatchinproject;

import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

public class FifthActivity extends AppCompatActivity implements
        Fragment1.OnFragmentInteractionListener,
        Fragment1.OnDataPass,
        Fragment2.OnFragmentInteractionListener,
        Fragment2.OnDataPass,
        View.OnClickListener
{

    private Button btn1, btn2;
    private int WhichFragment=0;
    private Fragment fragment = null;
    private RelativeLayout rl_fragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth);
    }


    public void initObjects() {
        btn1 = (Button) findViewById(R.id.btn1);
        btn1.setOnClickListener(this);
        btn2 = (Button) findViewById(R.id.btn2);
        btn2.setOnClickListener(this);
        rl_fragment = (RelativeLayout) findViewById(R.id.rl_fragment);
    }

    public void onClick(View v) {
        if (v.getId() == R.id.btn1) {
            fragment = new Fragment1();
            start_fragment(fragment, 2);
            WhichFragment=1;
        } else if (v.getId() == R.id.btn2) {
            fragment = new Fragment2();
            start_fragment(fragment, 1);
            WhichFragment=2;
        }
    }



    public void start_fragment(Fragment f, int what_animate) {

        Bundle bundle = new Bundle();
        bundle.putString("from_where", "MainActivity");
        f.setArguments(bundle);
        if (f != null) {
            // ========== traditional transaction =================
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            if (what_animate==1)
                ft.setCustomAnimations(R.anim.enter, R.anim.exit, R.anim.pop_enter, R.anim.pop_exit);
            else
                ft.setCustomAnimations(R.anim.pull_in_from_bottom, R.anim.push_out_to_bottom, R.anim.overshoot, R.anim.bounce);
            ft.replace(R.id.rl_fragment, f);//, AllConstants.TAG_FRAGMENT);
            ft.addToBackStack(null);
            //fragmentTransaction.remove(activeFragment).commit();
            ft.commit();
        }

    }

    public void onDataPass(String data) {
    }

    @Override
    public void onFragmentInteraction(Uri uri) {
        //We can keep this empty
    }


}
