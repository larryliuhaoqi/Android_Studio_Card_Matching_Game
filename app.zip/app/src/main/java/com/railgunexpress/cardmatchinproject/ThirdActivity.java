package com.railgunexpress.cardmatchinproject;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.widget.ImageButton;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class ThirdActivity extends Activity implements View.OnClickListener {

    int ScreenHeight, ScreenWidth;
    private float density;
    private double ScreenRatio;
    ImageButton ib_you_win;
    int Pair_matched = 0;

    // We define an integer array storing the 20 image button ID in activity_main.xml
    int card_id[] = {R.id.ib_4x5_01, R.id.ib_4x5_02, R.id.ib_4x5_03, R.id.ib_4x5_04,
            R.id.ib_4x5_05, R.id.ib_4x5_06, R.id.ib_4x5_07, R.id.ib_4x5_08,
            R.id.ib_4x5_09, R.id.ib_4x5_10, R.id.ib_4x5_11, R.id.ib_4x5_12, R.id.ib_4x5_13,
            R.id.ib_4x5_14, R.id.ib_4x5_15, R.id.ib_4x5_16, R.id.ib_4x5_17, R.id.ib_4x5_18,
            R.id.ib_4x5_19, R.id.ib_4x5_20};
    // We define imagebutton variables to map the20 image buttons in activity_mail.xml
    ImageButton ib[] = new ImageButton[20];

    // Assume we have randomized the cards as follows:
    // You should write your random card function in your project
    // We use card_val integer array to store the card image, e.g. R.drawable.lab12_card_animal_deer
    int card_val[] = {
            R.drawable.lab12_card_starwar_01, R.drawable.lab12_card_starwar_02,
            R.drawable.lab12_card_starwar_03, R.drawable.lab12_card_starwar_04,
            R.drawable.lab12_card_starwar_03, R.drawable.lab12_card_starwar_04,
            R.drawable.lab12_card_starwar_05, R.drawable.lab12_card_starwar_06,
            R.drawable.lab12_card_starwar_01, R.drawable.lab12_card_starwar_06,
            R.drawable.lab12_card_starwar_05, R.drawable.lab12_card_starwar_02,
            R.drawable.lab12_card_starwar_08, R.drawable.lab12_card_starwar_07,
            R.drawable.lab12_card_starwar_09, R.drawable.lab12_card_starwar_10,
            R.drawable.lab12_card_starwar_07, R.drawable.lab12_card_starwar_10,
            R.drawable.lab12_card_starwar_09, R.drawable.lab12_card_starwar_08,
    };

    // We define two integer to temporarily store firstcard and secondcard selected by player
    int firstcard, secondcard;


    // We define two temp imagebutton to remember which xml imagebutton is tapped.
    ImageButton ib_firstcard, ib_secordcard;

    // We use cardflipped to count the card flipped. Max card flipped is 2.
    int cardflipped = 0;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        init_AdView();
        // In order to make onCreate more concise, we define initObject() for objects initialization.
        initObject();

        if (isNetworkAvailable())
            Log.d("Louis check:","It has internet connection.");
        else
            Log.d("Louis check:","It may be in airplane mode.");


        check_display();
    }



    private Boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager
                .getActiveNetworkInfo();
        return activeNetworkInfo != null
                && activeNetworkInfo.isConnectedOrConnecting();
    }

    public void init_AdView() {
        // Load an ad into the AdMob banner view.
        AdView adView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder()
                .setRequestAgent("android_studio:ad_template").build();
        adView.loadAd(adRequest);
    }

    public void check_display() {
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        ScreenHeight = dm.heightPixels;
        ScreenWidth = dm.widthPixels;
        ScreenRatio = (double) ScreenHeight/2056; //default_height;
        density = getApplicationContext().getResources().getDisplayMetrics().density;
    }

    public void initObject() {
        // Since we use array to store imagebutton and drawable, we can use for loop for object initialization.
        for (int i=0; i<card_id.length; i++) {
            ib[i] = (ImageButton) findViewById(card_id[i]);
            ib[i].setOnClickListener(this);
        }
        ib_you_win = (ImageButton) findViewById(R.id.ib_you_win);
        ib_you_win.setOnClickListener(this);
        ib_you_win.setVisibility(View.INVISIBLE);
        ib_you_win.setClickable(false);
    }

    public void onClick(View v) {

        if (v.getId() == R.id.ib_you_win) {
            ib_you_win.setVisibility(View.INVISIBLE);
            ib_you_win.setClickable(false);
        }

        for (int i=0; i<card_id.length; i++) {
            if (v.getId() == card_id[i]) {
                int card_back = v.getContext().getResources().getIdentifier(
                        "lab12_card_back4", "drawable",
                        v.getContext().getPackageName());
                AnimateFlipCard(0, ib[i],500, card_val[i], card_back);

                // Here is the logic of checking card
                // We don’t compare image filename, but we compare the corresponding drawable ID in Android.
                if (cardflipped == 0) {
                    // If no card is selected, this must be the first card. And record first card into temp variables
                    ib_firstcard = ib[i];
                    firstcard = card_val[i];
                    // card flipped count plus one
                    cardflipped++;
                } else if (cardflipped == 1) {
                    // Here is second card and we store second card info into variables
                    ib_secordcard = ib[i];
                    secondcard = card_val[i];

                    // We then compare first and second card drawable ID (integer)
                    if (firstcard == secondcard) {
                        // If they are the same, then fade out using fadeout animation
                        // The reason for the 1000ms delay because there is flip animation running for 500ms
                        // We have to tell the app to delay the program and wait until previous animation has finished.
                        FadeOutCardAnimation(ib_secordcard,500,1000);
                        FadeOutCardAnimation(ib_firstcard,500,1000);
                        if (Pair_matched+1 ==10) {
                            ib_you_win.setVisibility(View.VISIBLE);
                            ib_you_win.setClickable(true);
                            Pair_matched = 0;
                        }else Pair_matched++;
                    } else {
                        // If not, we need to flip the card back.
                        AnimateFlipCard(1000, ib_secordcard,500, card_back, card_val[i]);
                        AnimateFlipCard(1000, ib_firstcard,500, card_back, card_val[i]);

                    }
                    // No matter the card pair is correct or not, cardflipped must be reset to 0.
                    cardflipped = 0;
                }
            }
        }
    }

    public static void FadeOutCardAnimation(final ImageButton ivDH, final int CardAnimTime, int DELAY) {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Alpha animation is about changing the opacity (visibility) of an object.
                // Alpha = 1.0f means visible (not transparent)
                // Alpha = 0.0f means invisible (transparent)
                // This animation function change an object alpha value from 1.0f to 0.0f
                AlphaAnimation alpha = new AlphaAnimation(1.0f, 0.0f);
                AnimationSet animationSet1 = new AnimationSet(true);
                animationSet1.addAnimation(alpha);
                // You can define the time taken for animation
                animationSet1.setDuration(CardAnimTime);
                ivDH.startAnimation(animationSet1);
                // Here you can set what to do after animation.
                // If not, the card will change from 0.0f to 1.0f again.
                // In Android, an object will return to the original state after animation.
                // We must set the final state after animation.
                ivDH.setVisibility(View.INVISIBLE);
            }
        }, DELAY);
    }

    public static void AnimateFlipCard(int DELAY, final ImageButton ivDH, final int CardAnimTime, final int ResId, final int card_back) {
        // Handler is used to DELAY an app from running
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // ((BitmapDrawable)ivDH.getDrawable()).getBitmap().recycle();
                ivDH.setImageResource(card_back);
                ivDH.setBackgroundResource(card_back);
                flipAnimation(ivDH, 1f, 0f, CardAnimTime);
            }
            // You can delay the app by typing the value here
        }, DELAY);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //((BitmapDrawable)imageView.getDrawable()).getBitmap().recycle();
                //((BitmapDrawable)ivDH.getDrawable()).getBitmap().recycle();
                ivDH.setImageResource(ResId);
                ivDH.setBackgroundResource(ResId);
                //ivDH.setVisibility(View.INVISIBLE);
                flipAnimation(ivDH, 0f, 1f, CardAnimTime);
            }
        }, DELAY+CardAnimTime/3);
    }

    public static void flipAnimation(ImageButton ivDH, float x1, float x2, int CardAnimTime)
    {
        // Flip animation is an optical illusion but changing the x axis scale from 100% to 0%
        // and then from 0% to 100% where an image is changed in between.
        Animation animationSet1 = new ScaleAnimation(
                x1, x2, // Start and end values for the X axis scaling
                1f, 1f, // Start and end values for the Y axis scaling

                // .5f pivot means the symmetry axis

                Animation.RELATIVE_TO_SELF, .5f, // Pivot point of X scaling
                Animation.RELATIVE_TO_SELF, .5f); // Pivot point of Y scaling
        //animationSet1.setFillAfter(true); // Needed to keep the result of the animation
        animationSet1.setDuration(CardAnimTime/3);
        ivDH.startAnimation(animationSet1);
    }


}
