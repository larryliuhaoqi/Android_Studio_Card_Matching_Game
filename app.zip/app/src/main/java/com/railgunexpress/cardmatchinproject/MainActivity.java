package com.railgunexpress.cardmatchinproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    DBHelper mydb;
    private ListView obj;
    TextView player_info;
    // You can access AllConstants class using ac as object instance
    AllConstants ac;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView) findViewById(R.id.text);

        //Load all contacts from the database and prepare the array adapter containing the array list
        mydb = new DBHelper(this);
        ArrayList<String> array_list = mydb.getAllContacts();
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, array_list);

        // Listview element and assign the array adapter to listview
        obj = (ListView) findViewById(R.id.listView1);
        obj.setAdapter(dataAdapter);

        // Create all the objects listeners
        addListenerOnButton();
        initObject();
    }

    public void initObject() {
        player_info = (TextView) findViewById(R.id.player_info);

        // The constants in ac can be accessed as follows:
        String t_info = "Coins:"+String.valueOf(ac.default_current_player_coh)+"\n"+
                "Level:"+String.valueOf(ac.default_current_player_level)+"\n"+
                "% Progress:"+String.valueOf(ac.default_current_player_level_progress);
        player_info.setText(t_info);
    }

    public void addListenerOnButton() {

        // Part 1: create the button listener
        Button button = (Button) findViewById(R.id.button1);
        button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Bundle dataBundle = new Bundle();
                dataBundle.putInt("id", 0);

                Intent intent = new Intent(getApplicationContext(),
                        DisplayContact.class);
                intent.putExtras(dataBundle);

                startActivity(intent);

            }

        });

        // Part 2: create the listview listener
        obj.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
                                    long arg3) {
                // TODO Auto-generated method stub
                int id_To_Search = arg2 + 1;

                Bundle dataBundle = new Bundle();
                dataBundle.putInt("id", id_To_Search);

                Intent intent = new Intent(getApplicationContext(),
                        DisplayContact.class);

                intent.putExtras(dataBundle);
                startActivity(intent);
            }
        });
    }

    //Create actionbar option menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }


    //Check when option menu item is selected
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);

        switch (item.getItemId()) {
            case R.id.item1: // item1 which means ADD NEW
                Bundle dataBundle = new Bundle();
                dataBundle.putInt("id", 0);

                Intent intent = new Intent(getApplicationContext(),
                        DisplayContact.class);
                intent.putExtras(dataBundle);

                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public boolean onKeyDown(int keycode, KeyEvent event) {
        // Move the task containing this activity to the back of the activity stack.
        if (keycode == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(true);
        }
        return super.onKeyDown(keycode, event);
    }

    public void Ganesh(View View)
    {
        String button_text;
        button_text =((Button)View).getText().toString();
        if(button_text.equals("3 x 4 Card Matching"))
        {
            Intent ganesh = new Intent(this,SeondActivity.class);
            startActivity(ganesh);
        }
        else if (button_text.equals("4 x 5 Card Matching"))
        {
            Intent mass = new Intent(this,ThirdActivity.class);
            startActivity(mass);

        }

        else if (button_text.equals("5 x 6 Card Matching"))
        {
            Intent mass = new Intent(this,ForthActivity.class);
            startActivity(mass);

        }

        else if (button_text.equals("Fragment"))
        {
            Intent mass = new Intent(this,FifthActivity.class);
            startActivity(mass);

        }

        else if (button_text.equals("Animation"))
        {
            Intent mass = new Intent(this,AnimationActivity.class);
            startActivity(mass);

        }
    }
}